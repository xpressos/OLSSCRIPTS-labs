<?PHP
if (!$GLOBALS['_LICENSE_INC']) {
$GLOBALS['_LICENSE_INC']=1;

$GLOBALS['License'] = "youremail";

} // end of inclusive if
?>