<?php

if (!isset($GLOBALS['_CONSTANTS_USER_INC']))
{
	$GLOBALS['_CONSTANTS_USER_INC'] = 1;

	// The pattern to display dates inside the application
	$GLOBALS['DateFormat'] = "m/d/Y g:i A";

	// The pattern to display dates in the short format inside the application
	$GLOBALS['DateShortFormat'] = "m/d/Y";

	// The characters used as thousands and decimal separators in the exported CSV reports
	$GLOBALS['ThousandsSeparatorCSV'] = "";
	$GLOBALS['DecimalSeparatorCSV'] = ".";

	// The interval to keep the tracking cookie (in seconds)
	//   86400 -  1 day
	//  432000 -  5 days
	//  864000 - 10 days
	// 1728000 - 20 days
	// 2592000 - 30 days
	$GLOBALS['CookieTimeout'] = 2592000;

	// Name of the page that performs the Double Meta Refresh Redirects
	$GLOBALS['DoubleMetaRedirectPage'] = "baseredirect.php";

	// Name of the page that performs the Base Loop Redirects
	$GLOBALS['LoopRedirectPage'] = "baseloopredirect.php";

	// The Clickbank Secret Key used in your Clickbank account
	$GLOBALS['ClickbankSecretKey'] = "";

	// Statuses sent from Clickbank that will mark a conversion in CPV Lab
	$GLOBALS['ClickbankSaleStatus'] = array("SALE", "JV_SALE", "BILL", "JV_BILL");
	
	// 'true' if logging for the Clickbank requests is enabled
	$GLOBALS['ClickbankPixelLogging'] = "false";

	// 'true' if logging for the Affiliate Window requests is enabled
	$GLOBALS['AffiliateWindowPixelLogging'] = "false";
	
	// Statuses sent from BlueSnap that will mark a conversion in CPV Lab
	$GLOBALS['BlueSnapSaleStatus'] = array("CHARGE");
	
	// 'true' if logging for the BlueSnap requests is enabled
	$GLOBALS['BlueSnapPixelLogging'] = "false";

	// Request method to use for 3rd party pixel calls. Possible values:
	// 'auto' - default option; CPV Lab automatically selects the request method based on server settings
	// 'contents' - use the file_get_contents PHP function for requests
	// 'curl' - use cURL for requests
	$GLOBALS['RequestMethod'] = "auto";

	// 'true' if referrers should be captured as full URL, including the query string
	$GLOBALS['CaptureFullReferrer'] = "false";

	// if the visitors' IP address is passed using a custom header, specify the header name here. Useful when running reverse proxies
	$GLOBALS['CustomIpHeader'] = "";
	
	// 'false' if parameters appended by the base pages should not be URL encoded; default value is 'true'
	$GLOBALS['UrlEncodeParameters'] = "true";
	
	// The maximum number of items that will be displayed in the multiselect controls
	$GLOBALS['MaxMultiselectItems'] = 1000;
	
	// Controls if cached data are used in application ("true" or "false" values); you must also setup the Cache Cron job
	$GLOBALS['UseDataCaching'] = "false";
	// The maximum number of clicks processed in a single Cron job execution
	$GLOBALS['CachingMaxItems'] = 10000;
	// The delay in aggregating clicks - clicks from the last xxx seconds won't be aggregated yet - in seconds
	//     300 -  5 minutes
	//     600 - 10 minutes
	//     900 - 15 minutes
	//    1800 - 30 minutes
	$GLOBALS['CachingDelay'] = 600;
	// The interval after which clicks are removed from the "clicks" table (after these clicks have been aggregated) - in seconds
	//   86400 -  1 day
	//  432000 -  5 days
	//  864000 - 10 days
	// 1728000 - 20 days
	// 2592000 - 30 days
	// 7776000 - 90 days
	$GLOBALS['CachingRemoveTime'] = 7776000;
	// The interval after which conversions cannot be marked in the aggregated data - in seconds
	//   86400 -  1 day
	//  432000 -  5 days
	//  864000 - 10 days
	// 1728000 - 20 days
	// 2592000 - 30 days
	// 7776000 - 90 days
	$GLOBALS['CachingRemoveCacheRelation'] = 2592000;
	
	//Controls if the GEO details are pulled by the Cron job; otherwise they are captured by the base.php page
	$GLOBALS['UseGeoCron'] = "false";
	
	// The maximum number of clicks geo-encoded in a single Cron job execution
	$GLOBALS['GeoMaxItems'] = 20000;
	
} // end of inclusive if
?>